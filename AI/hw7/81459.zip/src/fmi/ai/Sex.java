package fmi.ai;

public enum Sex {
    MALE,
    FEMALE;
}
